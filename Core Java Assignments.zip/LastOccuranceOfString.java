
import java.util.*;
public class LastOccuranceOfString 
{

	public static void main(String[] args) 
        {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter String");
		String str  =sc.nextLine();
		System.out.println("Enter substring");
		String str1  =sc.nextLine();
		System.out.println(str.lastIndexOf(str1));
		

	}

}
