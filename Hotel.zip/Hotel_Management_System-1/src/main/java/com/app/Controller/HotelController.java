package com.app.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.app.Service.AppService;
import com.app.model.Hotel;

@Controller
public class HotelController {

	@Autowired
	private AppService appService;
	
	@RequestMapping(path = "/home", method = RequestMethod.GET)
	public String getAdminLogin() {
		return "index";
	}
	
	@GetMapping("/showNewHotelForm")
	public String showNewBatchForm(Model model) {
		// create model attribute to bind form data
		Hotel hotel = new Hotel();
		model.addAttribute("hotel", hotel);
		return "new_hotel";
	}
	
	@PostMapping("/saveHotel")
	public String saveEmployee(@ModelAttribute("batch") Hotel hotel) {
		appService.saveHotel(hotel);
		return "redirect:/viewList";
	}
	
	@GetMapping("/showFormForUpdate/{id}")
	public String showFormForUpdate(@PathVariable(value = "id") int id, Model model) {
		Hotel hotel =appService.getHotelbyId(id);
		model.addAttribute("hotel", hotel);
		
		return "update_Hotel";
	}
	@GetMapping("/deleteHotel/{id}")
	public String deleteEmployee(@PathVariable(value = "id") int id) {
		this.appService.deleteHotelbyId(id);
		return "redirect:/viewList";

	}
	
	@GetMapping("/viewList")
	public String viewList(Model model) {
		List<Hotel> hotel=appService.getAllInfo();
		model.addAttribute("hotellist", hotel);
		return "viewList";
	}
	
	@RequestMapping(path="/LoginPage",method=RequestMethod.GET)
	public String showLoginPage() {
		return "index";
	}
	
}
