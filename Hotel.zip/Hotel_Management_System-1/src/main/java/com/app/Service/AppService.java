package com.app.Service;

import java.util.List;

import com.app.model.Hotel;

public interface AppService {

	List<Hotel> getAllInfo();
	void saveHotel(Hotel hotel);
	void deleteHotelbyId(long id);
	Hotel getHotelbyId(long id);
}
