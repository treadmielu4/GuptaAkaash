package com.app.Service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.app.Repository.HotelRepository;
import com.app.model.Hotel;

@Service
public class AppServiceImp implements AppService {

	@Autowired
	private HotelRepository hotelrepo;
	@Override
	public List<Hotel> getAllInfo() {
		return hotelrepo.findAll();
	}

	@Override
	public void saveHotel(Hotel hotel) {

		this.hotelrepo.save(hotel);
	}

	@Override
	public void deleteHotelbyId(long id) {

		this.hotelrepo.deleteById(id);
	}

	@Override
	public Hotel getHotelbyId(long id) {
		
		Optional<Hotel> optional=hotelrepo.findById(id);
		Hotel hotel=null;
		if(optional.isPresent()) {
			hotel=optional.get();
		}
		else 
		{
			throw new RuntimeException("Employee not found for id:: "+ id);
		}
		return hotel;

	}

}
